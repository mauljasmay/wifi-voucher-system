import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { MikroTikManager } from '@/lib/mikrotik';

// Middleware to check if user is authenticated
async function isAuthenticated(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.substring(7);
  return verifyToken(token);
}

export async function POST(request: NextRequest) {
  try {
    const admin = await isAuthenticated(request);
    if (!admin) {
      return NextResponse.json(
        { error: 'Akses ditolak' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { settingsId } = body;

    if (!settingsId) {
      return NextResponse.json(
        { error: 'Settings ID diperlukan' },
        { status: 400 }
      );
    }

    // Get settings
    const settings = await db.mikroTikSettings.findUnique({
      where: { id: settingsId }
    });

    if (!settings) {
      return NextResponse.json(
        { error: 'Pengaturan tidak ditemukan' },
        { status: 404 }
      );
    }

    // Test connection
    const mikrotik = new MikroTikManager({
      host: settings.host,
      port: settings.port,
      username: settings.username,
      password: settings.password,
      version: settings.version as 'v6' | 'v7',
      useSSL: settings.useSSL,
      timeout: settings.timeout
    });

    const connectionTest = await mikrotik.testConnection();
    let systemInfo = null;
    let profiles = [];

    if (connectionTest) {
      try {
        await mikrotik.connect();
        systemInfo = await mikrotik.getSystemInfo();
        profiles = await mikrotik.getProfiles();
        await mikrotik.disconnect();
      } catch (error) {
        console.error('Error getting system info:', error);
      }
    }

    // Update settings with test result
    await db.mikroTikSettings.update({
      where: { id: settingsId },
      data: {
        connectionStatus: connectionTest ? 'connected' : 'failed',
        lastConnected: connectionTest ? new Date() : null,
        errorMessage: connectionTest ? null : 'Koneksi gagal'
      }
    });

    return NextResponse.json({
      success: connectionTest,
      systemInfo,
      profiles,
      message: connectionTest ? 'Koneksi berhasil' : 'Koneksi gagal'
    });

  } catch (error) {
    console.error('Test MikroTik connection error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    );
  }
}